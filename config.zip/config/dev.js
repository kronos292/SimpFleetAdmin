module.exports = {
  //mongoURI:
  /* mongo CDN */
  //"mongodb+srv://testerssd:testerssd@cluster0-e1rew.mongodb.net/simpfleet_db?retryWrites=true&w=majority",
  secretOrKey: "secret",
  email_direct: "zulkarnain.ahmad18@gmail.com",
  email: "tester.ssd21@gmail.com",
  password: "SScode18",
  AWS_KEY: "AKIAIJLYJRIHDLCNC5IQ",
  AWS_SECRET: "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",
  MONGO_CONNECT_BUCKET: "ship-supplies-direct-consol-mongodb-key",
  MONGO_CONNECT_KEY: "id_rsa_consol",
  MONGO_USER: "ec2-user",
  MONGO_HOST: "ec2-54-169-203-223.ap-southeast-1.compute.amazonaws.com",
  MONGO_PORT: "22",
  DESTINATION_PORT: "27017",
  LOCAL_PORT: "2000",
  MONGO_URI: "mongodb://127.0.0.1:2000/Consol-Staging",
  SIMPFLEET_TELEGRAM_BOT_TOKEN: "865124865:AAGKjk2YOrKhIngGsdXDQFohRJNywpy-x7E",
  SIMPFLEET_TELEGRAM_CHAT_ID: "-1001398613457",
  SHIP_SUPPLIES_DIRECT_SALES_EMAIL: "service@fleetshare.ai",
  SHIP_SUPPLIES_DIRECT_SALES_EMAIL_PASSWORD: "FSpw90share*",
  SHIP_SUPPLIES_DIRECT_TEAM_EMAIL: "service@fleetshare.ai",
  COOKIE_KEY: "45hsdfh9dgj3kl324n2lefn"
};
